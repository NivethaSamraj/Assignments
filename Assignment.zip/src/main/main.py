import sys
from src.calculator import sinh


def main():
    num = float(sys.argv[1])
    res = sinh.sine_h(num)
    print(res)
