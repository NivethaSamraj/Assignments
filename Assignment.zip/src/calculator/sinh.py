
"""MODULE IS USED TO FIND SINH VALUE"""


def sine_h(x_value):
    """formula for finding sin"""
    exp_value = 2.71828
    try:
     sinh_of_x = (exp_value ** x_value - exp_value ** (- x_value)) / 2
     return sinh_of_x

    except Exception as e:
        print("Exception handled")

