"""PRog"""
import unittest
from src.calculator import sinh

class MyTestCase(unittest.TestCase):
    """test case class"""
    def test_1(self):
        """positive value"""
        self.assertEqual(sinh.sine_h(30), 5343129467557.554)

    def test_2(self):
        """negative value"""
        self.assertEqual(sinh.sine_h(-1), -1.1752001556866842)

    def test_3(self):
        """zero"""
        self.assertEqual(sinh.sine_h(0), 0)

if __name__ == '__main__':
    unittest.main()
